package main

import (
	"fmt"
	"sync"
)

func main() {
	var wg sync.WaitGroup
	a := 5000
	for i := 0; i < a; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			fmt.Println(id)
		}(i)
	}
	wg.Wait()
}
