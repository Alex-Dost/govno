package main

import (
	"fmt"
	"sync"
)

func main() {
	var wg sync.WaitGroup

	// Количество горутин
	numGoroutines := 4

	// Добавляем numGoroutines в WaitGroup
	wg.Add(numGoroutines)

	for i := 1; i <= numGoroutines; i++ {
		go func(id int) {
			defer wg.Done() // Уменьшаем счётчик после завершения
			//time.Sleep(time.Duration(id) * time.Millisecond)
			fmt.Printf("Горутина %d завершила работу\n", id)
		}(i) // Передаём номер горутины как параметр
	}

	// Ожидаем завершения всех горутин
	wg.Wait()
	fmt.Println("Все горутины завершены")
}
