package main

import (
	"fmt"
	"sort"
)

//Что выведет код?

func main() {
	v := []int{3, 4, 1, 2, 5}
	v2 := ap(v)
	sr(v2)
	fmt.Println(v2)
}

func ap(arr []int) []int {
	newArr := append(arr, 10)
	return newArr
}

func sr(arr []int) []int {
	newArr := append(arr)
	sort.Ints(newArr)
	return newArr
}
