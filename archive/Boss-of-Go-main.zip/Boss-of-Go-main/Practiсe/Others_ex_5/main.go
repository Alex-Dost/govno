// Задача 5
//1. Расскажи подробно что происходит
//2. Как сделать так, чтобы работало?
//
//package main
//
//import "fmt"
//
//func main() {
//    str := "Привет"
//    str[2] = 'e'
//    fmt.Println(str)
//}

package main

func main() {

}
