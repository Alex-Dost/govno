//Будет ошибка что все горутины заблокированы. Какие горутины будут заблокированы? И почему?

package main

import "fmt"

func main() {
	ch := make(chan int)
	go func() {
		ch <- 1
	}()
	fmt.Println(<-ch)
}
