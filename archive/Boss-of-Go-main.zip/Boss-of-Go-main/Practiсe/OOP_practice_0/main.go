package main

import "fmt"

type Animal struct {
	Name string
}

func (a Animal) Speak() {
	fmt.Printf(a.Name, "%s makes a sound\n")

}

type Dog struct {
	Animal
}

func (d Dog) Bark() {
	fmt.Println(d.Name, "barks")
}
func main() {
	pug := Dog{Animal{Name: "Бося"}}
	pug.Bark()
}
