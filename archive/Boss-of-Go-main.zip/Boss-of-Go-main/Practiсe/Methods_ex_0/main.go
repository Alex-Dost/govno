package main

import "fmt"

type Rectangle struct{ Width, Height float64 }

func (r Rectangle) Area() float64 {
	return r.Width * r.Height
}

func (r Rectangle) Perimeter() float64 {
	return (r.Width + r.Height) * 2
}

func main() {
	rectangle1 := Rectangle{Width: 15, Height: 8}
	fmt.Println(rectangle1.Area(), rectangle1.Perimeter())
}
