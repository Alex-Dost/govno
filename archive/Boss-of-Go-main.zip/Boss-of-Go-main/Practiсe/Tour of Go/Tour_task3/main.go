// return a map of the counts of each “word” in the string s
// [word, count]
package main

import (
	"fmt"
	"strings"
)

func main() {

	var s = "success or failure"
	fmt.Println(strings.Fields(s), len(strings.Fields(s)))
	mmap := make(map[string]int)
	for i := 0; i < len(strings.Fields(s)); i++ {
		mmap[strings.Fields(s)[i]] = i
	}
	fmt.Println(mmap)
}

//func WordCount(s string) map[string]int {
//	mmap := map[string]int{"x": 1}
//	for i := 0, i <= strings.Fields(s), i++ {
//
//	}
//	mmap[strings.Fields(s)] =
//	return mmap
//}
