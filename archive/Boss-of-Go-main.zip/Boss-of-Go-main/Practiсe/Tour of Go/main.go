package main

import "fmt"

// Создай структуру Rectangle с полями Width и Height (оба типа float64).
//Напиши два метода для этой структуры:
//Area() — возвращает площадь прямоугольника.
//Perimeter() — возвращает периметр прямоугольника.
//В функции main создай экземпляр Rectangle, задай значения для ширины и высоты,
// а затем вызови оба метода, чтобы вывести площадь и периметр на экран.

type Rectangle struct{ Width, Height float64 }

func (r Rectangle) Area() float64 {
	return r.Width * r.Height
}

func (r Rectangle) Perimeter() float64 {
	return (r.Width + r.Height) * 2
}

func main() {
	rectangle1 := Rectangle{Width: 15, Height: 8}
	fmt.Println(rectangle1.Area(), rectangle1.Perimeter())
}
