# Function Closure

Это функции 