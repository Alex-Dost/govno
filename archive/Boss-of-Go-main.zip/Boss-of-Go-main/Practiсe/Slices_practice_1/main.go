package main

import (
	"fmt"
	"sort"
)

// Что выведет код?
func main() {
	firstSlice := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	fmt.Println(double(firstSlice))
	fmt.Println(firstSlice)

	var list []int
	fmt.Println(list == nil)
	list = []int{}
	fmt.Println(len(list) == 0)

	s1 := []int{1, 2}
	s1 = append(s1, 3)
	fmt.Println(s1)
}

func ap(arr []int) []int {
	arr = append(arr, 10)
	return arr // возвращаем слайс, чтобы получить изменения не локально
}

func sr(arr []int) {
	sort.Ints(arr)
}

func double(slice []int) []int {
	newSlice := make([]int, 0, 4)
	for _, num := range slice {
		newSlice = append(newSlice, num*2)
	}
	return newSlice
}
