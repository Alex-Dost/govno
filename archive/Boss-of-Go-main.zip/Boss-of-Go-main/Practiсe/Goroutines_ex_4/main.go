package main

import "fmt"

// Задача 4 Как это работает, что не так, что поправить?

//func main() {
//	ch := make(chan bool, 1)
//	ch <- true
//	go func() {
//		<-ch
//	}()
//	ch <- true
//
//}

func main() {

	ch := make(chan bool)

	go func() {
		ch <- true
	}()

	fmt.Println(<-ch)
}
