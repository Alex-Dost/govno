package main

import (
	"fmt"
	"sync"
)

// Задача1 : Что выведет код? Исправить все проблемы
//

func main() {
	ch := make(chan int)
	wg := &sync.WaitGroup{}
	wg.Add(3)
	for i := 0; i < 3; i++ {
		go func(v int) {
			defer wg.Done()
			ch <- v * v
		}(i)
	}
	// канал не закрывался и из-за этого происходил deadlock
	// закрываем канал отдельной горутиной после завершения всех задач
	go func() {
		wg.Wait() // ждем закрытия всех горутин
		close(ch)
	}()

	var sum int
	for v := range ch {
		sum += v
	}

	fmt.Printf("result: %d\n", sum)
}
