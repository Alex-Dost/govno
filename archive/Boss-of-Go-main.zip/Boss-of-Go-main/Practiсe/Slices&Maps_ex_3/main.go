package main

import "fmt"

func main() {
	c := []string{"A", "B", "D", "E"}
	b := c[1:2]         // [B]
	b = append(b, "TT") //b = [B, TT];
	//срез b ссылается на подлежащий массив c как ["B", "D", "E"] потому что его емкость = 3
	//поэтому c изменился на ["A", "B", "TT", "E"]
	fmt.Println(c)
	fmt.Println(b)
}
