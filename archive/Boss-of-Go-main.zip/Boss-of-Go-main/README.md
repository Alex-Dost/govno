# Boss-of-Go

Дневник
https://docs.google.com/spreadsheets/d/1TIjdorgh8eoEua4pL-_RAbZ0t_2mXx59Jt8rQFXu_Vg/edit?usp=sharing
