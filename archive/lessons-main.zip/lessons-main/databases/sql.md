# Базовый SQL запрос

```sql
SELECT * FROM users
```
