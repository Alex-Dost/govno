package main

import (
	"fmt"
	"io"
	"os"
)

func main() {
	str := "Bbbpbobob"
	age := 22
	s := fmt.Sprintf("%s is %d dwadwadwadw ", str, age)
	fmt.Printf("%s is %d dxwdxww", str, age)

	io.WriteString(os.Stdout, s)

}
