package main

import (
	"fmt"
	"strings"
)

func main() {
	var builder strings.Builder

	for i := range 10 {
		i = i
		builder.WriteString("Hello")
		fmt.Println(builder.String())
	}

	b := []byte{}

	b = append(b, "Hello"...)
	b = append(b, "World"...)

	result := string(b)

	fmt.Println(result)
}
