package main

import "fmt"

func main() {
	hel := "Hello"
	space := " "
	wr := "world"

	fmt.Println(hel + space + wr)
}
