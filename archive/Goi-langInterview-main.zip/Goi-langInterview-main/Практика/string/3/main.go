package main

import (
	"fmt"
	"strings"
)

func main() {
	str := "Hello World"

	index := strings.Index(str, "world")

	if index != -1 {
		fmt.Println("Найдена посдстрока")
	}

	if strings.Contains(str, "Hello") {
		fmt.Println("Присутствует подстрока")
	}
}
