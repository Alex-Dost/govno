package main

import "fmt"

func main() {
	n := map[string]int{"a": 1, "с": 2, "b": 3, "w": 4, "d": 5, "e": 6, "f": 7, "z": 8}

	newSlice := []string{}

	for k, _ := range n {
		newSlice = append(newSlice, k)
	}
	fmt.Println(newSlice)
	for i := range newSlice {
		fmt.Println(n[newSlice[i]])
	}
}
