package main

import "fmt"

func main() {
	n := map[string]int{"a": 1, "a": 1, "b": 3, "w": 4, "d": 5, "e": 6, "f": 7, "z": 8}

	fmt.Println(n)
}
