package main

import (
	"fmt"
	"sync"
)

// Функция для слияния сигналов из нескольких каналов в один с закрытием всех каналов при закрытии одного
func mergeWithClose(channels ...<-chan int) <-chan int {
	// Результирующий канал
	out := make(chan int)

	// Канал для уведомления о закрытии
	done := make(chan struct{})
	var wg sync.WaitGroup
	wg.Add(len(channels))

	// Запускаем горутину для каждого канала
	for _, ch := range channels {
		go func(c <-chan int) {
			defer wg.Done()
			for {
				select {
				case val, ok := <-c:
					if !ok {
						// Если один канал закрыт, закрываем done канал
						close(done)
						return
					}
					out <- val
				case <-done:
					// Если получили сигнал закрытия, завершаем горутину
					return
				}
			}
		}(ch)
	}

	// Закрываем результирующий канал, когда все горутины завершат работу
	go func() {
		wg.Wait()
		close(out)
	}()

	return out
}

func main() {
	// Создаем несколько каналов
	ch1 := make(chan int)
	ch2 := make(chan int)
	ch3 := make(chan int)

	// Запускаем горутины для отправки данных в каналы
	go func() {
		ch1 <- 1
		ch1 <- 2
		close(ch1) // Закрываем ch1, что должно привести к закрытию всех
	}()

	go func() {
		ch2 <- 3
		ch2 <- 4
	}()

	go func() {
		ch3 <- 5
		ch3 <- 6
	}()

	// Получаем слияние сигналов
	out := mergeWithClose(ch1, ch2, ch3)

	// Читаем из результирующего канала
	for val := range out {
		fmt.Println(val)
	}
}
