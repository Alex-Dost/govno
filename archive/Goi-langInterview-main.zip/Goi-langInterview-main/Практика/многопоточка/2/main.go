package main

import "fmt"

func main() {
	// Создаем небуферизированный канал
	ch := make(chan int)

	// Пытаемся записать значение в канал
	ch <- 1

	// Пытаемся прочитать значение из канала
	val := <-ch
	fmt.Println(val)
}
