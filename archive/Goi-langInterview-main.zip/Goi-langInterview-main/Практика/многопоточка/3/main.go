package main

import "fmt"

func main() {
	// Создаем буферизированный канал с буфером на 1 элемент
	ch := make(chan int, 1)

	// Записываем значение в буферизированный канал
	ch <- 1

	// Читаем значение из канала
	val := <-ch
	fmt.Println(val)
}
