package main

import (
	"fmt"
	"runtime"
	"time"
)

func loop1() {
	for {
		fmt.Println("Loop 1 is running")
		time.Sleep(500 * time.Millisecond) // Добавляем паузу для демонстрации переключения
	}
}

func loop2() {
	for {
		fmt.Println("Loop 2 is running")
		time.Sleep(500 * time.Millisecond) // Добавляем паузу для демонстрации переключения
	}
}

func main() {
	// Устанавливаем GOMAXPROCS в 1
	runtime.GOMAXPROCS(1)

	// Запускаем две горутины с бесконечными циклами
	go loop1()
	go loop2()

	// Держим основную программу запущенной
	select {}
}
