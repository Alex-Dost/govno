package main

import (
	"fmt"
	"sync"
)

// Функция для слияния сигналов из нескольких каналов в один
func merge(channels ...<-chan int) <-chan int {
	// Результирующий канал
	out := make(chan int)

	var wg sync.WaitGroup
	wg.Add(len(channels))

	// Запускаем горутину для каждого канала
	for _, ch := range channels {
		go func(c <-chan int) {
			for val := range c {
				out <- val // Отправляем значения в результирующий канал
			}
			wg.Done()
		}(ch)
	}

	// Закрываем результирующий канал, когда все горутины завершат работу
	go func() {
		wg.Wait()
		close(out)
	}()

	return out
}

func main() {
	// Создаем несколько каналов
	ch1 := make(chan int)
	ch2 := make(chan int)
	ch3 := make(chan int)

	// Запускаем горутины для отправки данных в каналы
	go func() {
		ch1 <- 1
		ch1 <- 2
		close(ch1)
	}()

	go func() {
		ch2 <- 3
		ch2 <- 4
		close(ch2)
	}()

	go func() {
		ch3 <- 5
		ch3 <- 6
		close(ch3)
	}()

	// Получаем слияние сигналов
	out := merge(ch1, ch2, ch3)

	// Читаем из результирующего канала
	for val := range out {
		fmt.Println(val)
	}
}
