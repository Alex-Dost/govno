package main

import (
	"fmt"
	"sync"
	"time"
)

// Горутина, в которую передается WaitGroup по указателю
func workerWithPointer(id int, wg *sync.WaitGroup) {
	defer wg.Done() // Обязательно уменьшаем счётчик по завершении
	fmt.Printf("Worker %d started (pointer)\n", id)
	time.Sleep(1 * time.Second)
	fmt.Printf("Worker %d finished (pointer)\n", id)
}

// Горутина, в которую передается WaitGroup по значению
func workerWithValue(id int, wg sync.WaitGroup) {
	defer wg.Done() // Это не повлияет на оригинальный WaitGroup
	fmt.Printf("Worker %d started (value)\n", id)
	time.Sleep(1 * time.Second)
	fmt.Printf("Worker %d finished (value)\n", id)
}

func main() {
	var wg sync.WaitGroup

	// Добавляем 5 горутин в счетчик WaitGroup
	wg.Add(5)

	// Запуск горутин с передачей WaitGroup по указателю
	for i := 1; i <= 3; i++ {
		go workerWithPointer(i, &wg)
	}

	// Запуск горутин с передачей WaitGroup по значению
	for i := 4; i <= 5; i++ {
		go workerWithValue(i, wg)
	}

	// Ожидаем завершения всех горутин
	wg.Wait()

	fmt.Println("All workers finished")
}
