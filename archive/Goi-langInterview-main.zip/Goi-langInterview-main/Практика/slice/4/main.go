package main

import "fmt"

func main() {
	var slice2 [][]int
	slice1 := []int{1, 2, 3, 4}
	slice3 := []int{4, 5, 6, 7}

	slice2 = append(slice2, slice1)
	slice2 = append(slice2, slice3)

	fmt.Println(slice2)

}
