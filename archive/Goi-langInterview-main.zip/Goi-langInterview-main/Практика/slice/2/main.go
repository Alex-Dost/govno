package main

func main() {
	newSLice := []int{}
	println(len(newSLice), cap(newSLice))

	newSLice = append(newSLice, 1)
	println(len(newSLice), cap(newSLice))
	newSLice = append(newSLice, 1)
	println(len(newSLice), cap(newSLice))
	newSLice = append(newSLice, 1)
	println(len(newSLice), cap(newSLice))
	newSLice = append(newSLice, 1)
	newSLice[3] = 25
	println(newSLice)
	println(len(newSLice), cap(newSLice))
	newSLice = append(newSLice, 1)
	println(len(newSLice), cap(newSLice))

}
