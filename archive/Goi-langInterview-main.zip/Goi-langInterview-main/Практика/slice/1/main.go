package main

import "fmt"

func modifySlice(s []int) {
	s[0] = 100 // Изменяем первый элемент слайса
}

func main() {
	nums := []int{1, 2, 3}
	fmt.Println("Before:", nums)
	numptr := &nums
	modifySlice(nums)

	fmt.Println("After:", nums)

	modifySlicePtr(numptr)

	fmt.Println(nums)
}

func modifySlicePtr(s *[]int) {

	slicenw := *s
	slicenw[0] = 25 // Изменяем слайс через указатель
}
