package main

func main() {
	slice1 := []int{1, 2, 3, 4, 5, 6, 7, 8}
	i := 2
	j := 4

	fprin := slice1[i:j]

	println(fprin)
}
