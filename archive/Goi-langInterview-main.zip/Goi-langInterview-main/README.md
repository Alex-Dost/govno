## Таблица Собесов
### New
https://docs.google.com/spreadsheets/d/1izJeXKCn-Ypcb7ciZcb3NCpwTAJdVwGw3tSFiN0d9W8/edit?gid=0#gid=0

### Old
https://docs.google.com/spreadsheets/d/1IbkrDyilztGec7pg668pKmPAZkYTGgVD6070YvJYIQc/edit?hl=ru&gid=0#gid=0
