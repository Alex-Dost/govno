
Массив - последовательность фикс длинны(состоит из фиксированного кол-ва данных)

Слайс - динамический массив - абстракция над массивом 
Содержит в себе: 
1. Length массива
2. Capacity  массива
3. Pointer на первый элемент массива
Обращается к массиву по ссылке через поинтер


myArr = []int{a,b,c,d,e,f,g,h}
len(myArr) = 8
cap(myArr) = 8

```
myArr = append(myArr, 8)
cap(myArr) = 16
len(myArr) = 9
```

```
slice = myArr[1:4]
len(slice) = 3
cap(slice) = 7
```


## Как работает функция Append?

```
var Bobdizka []int = {1,2,3,4,5}
len(Bobdizka) = 5
cap(Bobdizka) = 5

ptr(bobdizkak) = 1

Bobdizka = append(Bobdizka, 6)
cap = 10
len = 6

dizzy = Bobdizka[:3]
dizzy = append(dizzy, 4)


```


