
![[Pasted image 20241012171008.png]]