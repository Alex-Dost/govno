# GOblin


1. Курс на хекслете по Go: https://ru.hexlet.io/courses/go-basics
2. Курс на степике с большим количеством практики: https://stepik.org/course/158385/syllabus
3. Куча сниппетов кода с разными примерами от крутых прогеров с пояснением, что делает каждый кусок: https://gobyexample.com/
4. Большой кусок кода на Go с детальным пояснением происходящего: https://learnxinyminutes.com/docs/go/
5. Проект для практики, где находится сломанное CRUD-приложение, которое нужно поправить и внести best practice: https://github.com/MatthewJamesBoyle/golang-interview-prep
6. Большой список проектов (полезные инструменты, гайды) на Go: https://github.com/avelino/awesome-go
7. Идеи для пет-проекта: https://github.com/inancgumus/learngo
8. ТОП вопросов с ответами по собесу на Go разраба: https://docs.google.com/document/d/1OhigKR_M4EM5rL1B7jpoYqxYEwyzQzoTW4MtL27Ua00/edit#heading=h.tvecg1f7bylq ИЛИ https://github.com/goavengers/go-interview
9. Курс по разработке веб-сервисов: https://stepik.org/course/187490/promo
10. Статья на хабре по must have навыкам: https://habr.com/ru/companies/yandex_praktikum/articles/779954/
11. Курс на степике с большим количеством практики (платный) "Thank Go": https://stepik.org/course/96832/promo#toc
12. Полезные каналы: АйтиКрасавчик, Николай Тузов, Максим Жашкевич, TheArtOfDevelopment, Владимир Балун
13. Если стоит целевая задача максимально быстро спрогрессировать: Нормальный ментор или "Team Interview Hustlers" Макса Аверина
