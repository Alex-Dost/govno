package main

import (
	"theory/platform/practice/ozon"
)


func main(){
	ozon.T1()
}