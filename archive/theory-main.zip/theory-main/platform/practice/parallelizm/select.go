package parallelizm



// почитать про селект